/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int n,m;
    printf("enter row size ");
    scanf("%d",&n);
    printf("enter coloum size");
    scanf("%d",&m);
   int a[n][m],sum=0,i,j;
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           scanf("%d",&a[i][j]);
       }
   }
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
          printf("%d ",a[i][j]);
   }
     printf("\n");  
   }
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           if(i==j)
           {
               sum=sum+a[i][j];
           }
       }
   }
   printf("sum of main diagonal is %d",sum);
   


    return 0;
}


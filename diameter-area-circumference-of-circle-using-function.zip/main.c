/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void circle(float rad);
int main()
{
   float r;
   scanf("%f",&r);
   circle(r);

    return 0;
}
 
 void circle(float rad){
     printf("diameter of a circle is %f\n",2*rad);
     printf("circumference of a cicle is %f\narea of cicle is %f\n",(2*3.14*rad),(3.14*rad*rad));
 }
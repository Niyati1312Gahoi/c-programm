/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   
     int n,m,c=0;
    printf("enter row size ");
    scanf("%d",&n);
    printf("enter coloum size");
    scanf("%d",&m);
   int a[n][m],i,j;
   printf("enter elements of matrix\n");
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           scanf("%d",&a[i][j]);
       }
   }
   printf("martrix is \n");
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
          printf("%d ",a[i][j]);
           }
      printf("\n");    
   }
   int flag=0;
     
for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           if(i==j&& a[i][j]!=1)
          {
              flag=1;
              break;
          }
          else if(i!=j&&a[i][j]!=0)
          {
              flag=1;
              break;
          }
           }
   }
   if(flag==1)
{
    printf("matrix is not identity matrix");
}
else
    printf("matrix is a identiy matrix");


    return 0;
}

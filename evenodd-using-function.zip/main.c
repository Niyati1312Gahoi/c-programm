/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void evenodd(int n);
int main()
{
   int a;
   printf("enter number ");
   scanf("%d",&a);
   evenodd(a);

    return 0;
}
void evenodd(int n){
    if(n%2==0){
        printf("number is even");
    }
    else 
    printf("number is odd");
}
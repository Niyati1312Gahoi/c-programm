/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int n,m,c=0;
    printf("enter row size ");
    scanf("%d",&n);
    printf("enter coloum size");
    scanf("%d",&m);
   int a[n][m],i,j;
   printf("enter elements of matrix\n");
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           scanf("%d",&a[i][j]);
       }
   }
   printf("martrix is \n");
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
          printf("%d ",a[i][j]);
           }
      printf("\n");    
   }
     
for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           if(a[i][j]==0)
           c++;
           }
   }
   if(c>((n*m)/2))
{
    printf("matrix is sparse matrix");
}
else
    printf("matrix is not a sparse matrix");


    return 0;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m;
    printf("enter row size ");
    scanf("%d",&n);
    printf("enter coloum size");
    scanf("%d",&m);
   int a[n][m],b[n][m],sub[n][m],i,j;
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           scanf("%d",&a[i][j]);
       }
   }
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           scanf("%d",&b[i][j]);
       }
   }
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           sub[i][j]=a[i][j]-b[i][j];
       }
   }
   for(i=0;i<n;i++)
   {
       for(j=0;j<m;j++)
       {
           printf("%d\t",sub[i][j]);
       }
       printf("\n");
   }
   
   



    return 0;
}
